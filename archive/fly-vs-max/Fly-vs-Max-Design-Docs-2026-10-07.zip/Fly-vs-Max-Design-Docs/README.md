# Fly vs. Max — design workspace

Status: planning draft, revised October 5, 2026. No implementation has started.

Build a controller derived from the MaleCNS fruit-fly connectome and teach it to drive a fixed circuit, aiming to beat a published Hamilton or Verstappen lap time in an explicitly labeled cross-simulator comparison. Completing laps against a local baseline is an engineering milestone toward that objective.

For the implementation handoff, start with [15 — build handoff and remaining evidence](docs/15-build-handoff.md). It identifies the current specifications, seven build tickets, and the decisions that require actual access or measurements. The design is ready for staged qualification; no runtime result has been validated.

Start with the [Implementation roadmap](docs/10-implementation-roadmap.md) for the team checklist and the [Implementation contract](docs/11-implementation-contract.md) for exact interfaces, adaptive training, and acceptance checks. The contract takes precedence for implementation behavior. [Research update](docs/08-research-roadmap.md) and [Fixed-circuit controller](docs/09-fixed-circuit-controller.md) provide evidence and rationale. Documents 01–07 are supporting earlier drafts, not independent implementation specifications. Original Assetto Corsa plus AssettoCorsaGym remains conditional on access, permitted demo use, and integration checks; TORCS is the open-source fallback. No game choice has been installed or tested.

## Design documents

The revised [roadmap](docs/10-implementation-roadmap.md) is the single source for execution priority and time limits: first fly section by the provisional hour 14, a bounded eligible RL pilot, model freeze at hour 28, and the final eight hours for scoring/demo/submission. Start with one graph candidate, a small inspected dataset, and one conventional baseline. Corrections remain the fallback if RL stalls. Old schedules and experiment menus are not additional required work.

1. [Project brief](docs/01-project-brief.md): original EA F1 scope and success criteria; read with the current refinement in documents 08–09.
2. [System design](docs/02-system-design.md): reusable fly network and hardware design; EA adapter remains an alternative.
3. [Training and evaluation](docs/03-training-and-evaluation.md): learning and experimental controls; EA benchmark conditional.
4. [Hackathon plan](docs/04-hackathon-plan.md): historical four-person schedule; replaced by document 10.
5. [Research and decisions](docs/05-research-and-decisions.md): primary sources and why the proposed design takes this shape.
6. [EA anti-cheat assessment](docs/06-ea-anticheat.md): compatibility uncertainty, permitted-use questions, and a draft inquiry for EA.
7. [Earlier simulator comparison](docs/07-simulator-selection.md): Trackmania/TORCS research and fallback implications; recommendation revised by document 08.
8. [Research update and execution roadmap](docs/08-research-roadmap.md): Beat Saber evidence limits, Assetto Corsa route, exact lap targets, and source-backed integration notes; scheduling lives in document 10.
9. [Fixed-circuit controller](docs/09-fixed-circuit-controller.md): concise rationale and data-flow diagram pointing to the current specifications.
10. [Implementation roadmap](docs/10-implementation-roadmap.md): authoritative priorities, smaller starting dataset, bounded graph/RL experiments, stop rules, four-person ownership, and a provisional 36-hour schedule protecting the final eight hours.
11. [Implementation contract and readiness checks](docs/11-implementation-contract.md): authoritative module boundaries, feature order, timing, lifecycle, correction/retraining, promotion/rollback, and outstanding decisions.
12. [Fly-network specification](docs/12-fly-network-specification.md): proposed graph retention, weight/sign processing, deterministic input/output mapping, dynamics, learned readout, and bounded qualification experiments. Takes precedence for network details.
13. [Hybrid learning plan](docs/13-hybrid-learning-plan.md): current training strategy combining demonstration initialization, autonomous RL practice, and optional human corrections. Supersedes imitation-only adaptation and late-RL assumptions in earlier drafts.
14. [Fly biology and model review](docs/14-fly-biology-and-model-review.md): beginner's guide to perception, navigation, movement, and learning; primary research; implications for memory, mapping, and experimental claims.
15. [Build handoff and remaining evidence](docs/15-build-handoff.md): reading order, unresolved team/access decisions, implementation tickets with proof of done, and planning completion audit.

Fill the [run-manifest template](docs/run-manifest.template.json) as decisions are confirmed. Its null values are intentional; it is not a runnable configuration.

Confirmed: four teammates, two with direct Spark access; Windows with Steam available; likely a gaming laptop with an RTX 3060; exclusive use of a DGX Spark over the internet; the Google-linked MaleCNS release; willingness to choose a simulator that enables the experiment. A real-world comparison is still an ambition, explicitly labeled as cross-simulator.

Proposed: remote training on DGX Spark and local simulator/inference on Windows; one fixed circuit/car; track-position and live-state observations; a sparse connectome-derived recurrent network with a learned control head; demonstration initialization followed by RL practice and optional human corrections. The primary fly actor receives no direct observation shortcut around the graph. These are design recommendations, not validated capabilities.

First gates: settle simulator access/use, verify observation/control/reset behavior, and benchmark full-graph local inference while the game runs. Then collect target-car demonstrations and check Spark-to-laptop checkpoint parity. Exact hackathon duration, game ownership, laptop specifications, and the Beat Saber implementation remain unconfirmed. Starting a commercial game offline does not, by itself, resolve its automation rules.
